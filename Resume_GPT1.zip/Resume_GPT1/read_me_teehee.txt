Please add your own .env file:

if you are a newb, please write a plane text file with your api.key
then save as a .env
not .env.txt just .env


OPENAI_API_KEY=sk-...your-api-key-here...